#!/usr/bin/env python3
from brain_games.games.gsd import find_gsd


def main():
    find_gsd()


if __name__ == "__main__":
    main()
