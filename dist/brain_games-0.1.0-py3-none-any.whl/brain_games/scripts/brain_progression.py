#!/usr/bin/env python3
from brain_games.games.progression import miss_number_progression


def main():
    miss_number_progression()


if __name__ == "main":
    main()
