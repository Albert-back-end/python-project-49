### Hexlet tests and linter status:
[![Actions Status](https://github.com/Albert-back-end/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Albert-back-end/python-project-49/actions)

Запись работы игры brain-even в asciinema
https://asciinema.org/a/m0dAR3InBXEFt52InkisR3Rga

Запись работы игры калькулятор в asciinema
https://asciinema.org/a/eT8qaYH630tJXVM4CwMJVTUSX