#!/usr/bin/env python3
from brain_games.games.prime import is_prime


def main():
    is_prime()


if __name__ == "main":
    main()
