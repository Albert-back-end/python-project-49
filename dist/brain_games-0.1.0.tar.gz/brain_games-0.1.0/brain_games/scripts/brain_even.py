#!/usr/bin/env python3
from brain_games.games.even_words import logic_of_brain_even


def main():
    logic_of_brain_even()


if __name__ == "main":
    main()